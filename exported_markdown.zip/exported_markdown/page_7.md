<!--
                                Source URL: https://www.efv.admin.ch/efv/it/home/efv/erechnung/aktuell.html
                                Page ID: 7
                                -->

                                





 

Attualità









































* [Homepage](/efv/it/home.html)
* [Main navigation](#main-navigation)
* [Content area](#content)
* [Sitemap](#site-map)
* [Search](#search-field)








Amministrazione federale delle finanze
--------------------------------------


* [Il Consiglio federale](#) 
	+ [Il Consiglio federale admin.ch](https://www.admin.ch/gov/it/pagina-iniziale.html)
		- [CaF: Cancelleria federale](https://www.bk.admin.ch/bk/it/home.html)
		- [DFAE: Dipartimento federale degli affari esteri](https://www.eda.admin.ch/eda/it/home.html)
		- [DFI: Dipartimento federale dell'interno](https://www.edi.admin.ch/edi/it/home.html)
		- [DFGP: Dipartimento federale di giustizia e polizia](https://www.ejpd.admin.ch/content/ejpd/it/home.html)
		- [DDPS: Dipartimento federale della difesa, della protezione della popolazione e dello sport](https://www.vbs.admin.ch/it)
		- [DFF: Dipartimento federale delle finanze](https://www.efd.admin.ch/it)
		- [DEFR: Dipartimento federale dell'economia, della formazione e della ricerca](https://www.wbf.admin.ch/wbf/it/home.html)
		- [DATEC: Dipartimento federale dell'ambiente, dei trasporti, dell'energia e delle comunicazioni](https://www.uvek.admin.ch/uvek/it/home.html)
* [DFF](#)
	+ [DFF: Dipartimento federale delle finanze](https://www.efd.admin.ch/it)
		- [SG\-DFF: Segreteria generale](https://www.efd.admin.ch/it/segreteria-generale)
		- [SIF: Segretario di Stato per le questioni finanziarie internazionali](https://www.sif.admin.ch/sif/it/home.html)
		- [AFF: Amministrazione federale delle finanze](https://www.efv.admin.ch/efv/de/home.html)
		- [UFPER: Ufficio federale del personale](https://www.epa.admin.ch/epa/it/home.html)
		- [AFC: Amministrazione federale delle contribuzioni](https://www.estv.admin.ch/estv/it/home.html)
		- [UDSC: Ufficio federale della dogana e della sicurezza dei confini](https://www.bazg.admin.ch/bazg/it/home.html)
		- [UFIT: Ufficio federale dell'informatica e della telecomunicazione](https://www.bit.admin.ch/bit/it/home.html)
		- [UFIT: Ufficio federale dell'informatica e della telecomunicazione](https://www.bbl.admin.ch/bbl/it/home.html)
		- [Delegata federale al plurilinguismo](https://www.plurilingua.admin.ch/plurilingua/it/home.html)
		- [FINMA: Autorità federale di vigilanza sui mercati finanziari](https://www.finma.ch/it/)
		- [CDF: Controllo federale delle finanze](https://www.efk.admin.ch/index.php?lang=it)
		- [PUBLICA: Cassa pensioni della Confederazione](https://publica.ch/it/home)
* [AFF](#)
	+ [Ufficio centrale di compensazione UCC](https://www.zas.admin.ch/zas/it/home.html)
		- [Swissmint](https://www.swissmint.ch/it)





Attualità
---------



* [DE](/efv/de/home/efv/erechnung/aktuell.html "tedesco")
* [FR](/efv/fr/home/efv/erechnung/aktuell.html "francese")
* IT
* [EN](/efv/en/home/efv/erechnung/aktuell.html "inglese")



Service navigation
------------------



* [Pagina iniziale](/efv/it/home.html "Pagina iniziale")
* [Contatto](/efv/it/home/efv/kontakt.html "Contatto")
* [Posti](https://www.efv.admin.ch/efv/it/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/it/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Servizi](https://eportal.admin.ch)







[![Amministrazione federale delle finanze AFF](/efv/it/_jcr_content/logo/image.imagespooler.png/1675673515094/logo.png)
Amministrazione federaledelle finanze AFF
-----------------------------------------](/efv/it/home.html "Pagina iniziale")







Navigation
----------








![Amministrazione federale delle finanze AFF](/etc/designs/core/frontend/guidelines/img/swiss.svg)

[AFF](/efv/it/home.html "Pagina iniziale")
------------------------------------------









* [Attualità](/efv/it/home/aktuell.html)


* [Temi](/efv/it/home/themen.html)


* [Rapporti finanziari](/efv/it/home/finanzberichterstattung.html)


* [L'AFF](/efv/it/home/efv.html)


















* [Attualità](/efv/it/home/aktuell.html)
	+ Chiudere
* [Temi](/efv/it/home/themen.html)
	+ Chiudere
* [Rapporti finanziari](/efv/it/home/finanzberichterstattung.html)
	+ Chiudere
* [L'AFFcurrent page](/efv/it/home/efv.html)
	+ Chiudere









Breadcrumb
----------


1. [Pagina iniziale](/efv/it/home.html "Pagina iniziale")
2. [L'AFF](/efv/it/home/efv.html "L'AFF")
3. [e\-fattura](/efv/it/home/efv/erechnung.html "e-fattura")
4. Attualità










[Unternavigation](#collapseSubNav)


[Zurück](/efv/it/home/efv.html)
[Zurück zu L'AFF](/efv/it/home/efv.html)
* [e\-fattura](/efv/it/home/efv/erechnung.html)
* Attualità selected
* [Breve introduzione](/efv/it/home/efv/erechnung/kurze-einfuehrung.html)
* [Emissione delle fatture elettroniche per la Confederazione](/efv/it/home/efv/erechnung/e-rechnung-zustellen.html)
* [Ricevimento delle fatture elettroniche della Confederazione](/efv/it/home/efv/erechnung/e-rechnung-empfangen.html)
* [Elenco delle unità amministrative](/efv/it/home/efv/erechnung/liste-verwaltungseinheiten.html)










[Context sidebar](#context-sidebar)








Attualità
=========






![e-fattura](/efv/it/home/efv/erechnung/aktuell/_jcr_content/par/textimage_1240019614/image.imagespooler.jpg/1649751484379/180.1000/e-rechnung_i.png)
Fate i conti con noi – ma elettronicamente!
-------------------------------------------





Trasmissione delle fatture per via elettronica
----------------------------------------------





Invece di stampare le fatture e di inviarle per posta all’Amministrazione federale, potete trasmettere elettronicamente i dati di fatturazione a un fornitore di prestazioni nell’ambito delle fatture elettroniche. Questa variante vi permette di risparmiare tempo e denaro. Inoltre consente di elaborare la fattura in maniera rapida e continua. I fornitori possono emettere le fatture in formato strutturato o PDF e trasmetterle tramite vari canali.


Maggiori informazioni:


[Emissione delle fatture elettroniche per la Confederazione](/efv/it/home/efv/erechnung/e-rechnung-zustellen.html)


[Ricevimento delle fatture elettroniche da parte della Confederazione](/efv/it/home/efv/erechnung/e-rechnung-empfangen.html)


Se avete domande su una fattura in particolare, contatta il Centro Prestazioni di servizi Finanze: [e\-rechnung@efv.admin.ch](mailto:e-rechnung@efv.admin.ch).





La quota delle fatture elettroniche ha già superato il 75 per cento
-------------------------------------------------------------------





Attualmente, la Confederazione riceve più del 75 per cento delle fatture per via elettronica. Da quando i fornitori della Confederazione sono tenuti a inviare fatture elettroniche, la quota di queste ultime è aumentata regolarmente passando dal 18 per cento del dicembre 2014 al 75 per cento del dicembre 2021, ossia a circa 488 000 delle 650 000 fatture emesse ogni anno. L’obbligo non concerne le fatture relative a piccole forniture.


Il 25 per cento circa delle fatture in uscita per clienti esterni è emesso elettronicamente (fattura elettronica strutturata o fattura in formato PDF via e\-mail). Questa possibilità risponde a un’esigenza diffusa dei clienti. La quota deve essere ulteriormente aumentata.









Ultima modifica 08\.06\.2022






[Inizio pagina](#) 







Social share










#### Carrello acquisti














https://www.efv.admin.ch/content/efv/it/home/efv/erechnung/aktuell.html

Footer
------




### Amministrazione federale delle finanze AFF



* [Pagina iniziale](/efv/it/home.html "Pagina iniziale")
* [Contatto](/efv/it/home/efv/kontakt.html "Contatto")
* [Posti](https://www.efv.admin.ch/efv/it/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/it/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Servizi](https://eportal.admin.ch)





Footer
------


[Sitemap](#site-map)



### Attualità


* [Informazioni ai media](/efv/it/home/aktuell/nsb-news_list.html "Informazioni ai media ")
* [Al centro dell'interesse](/efv/it/home/aktuell/brennpunkt.html "Al centro dell'interesse")
* [Archivio](/efv/it/home/aktuell/a.html "Archivio")






### Temi


* [Politica finanziaria, basi](/efv/it/home/themen/finanzpolitik_grundlagen.html "Politica finanziaria, basi")
* [Statistica finanziaria](/efv/it/home/themen/finanzstatistik.html "Statistica finanziaria")
* [Perequazione finanziaria](/efv/it/home/themen/finanzausgleich.html "Perequazione finanziaria ")
* [Raccolta di fondi, gestione del patrimonio e del debito](/efv/it/home/themen/mittelbeschaff_verm_schuldenverw.html "Raccolta di fondi, gestione del patrimonio e del debito")
* [Regime monetario](/efv/it/home/themen/waehrung_gewinnaussch_int.html "Regime monetario")
* [Progetti](/efv/it/home/themen/projekte.html "Progetti")
* [Pubblicazioni](/efv/it/home/themen/publikationen.html "Pubblicazioni")






### Rapporti finanziari


* [Panoramica delle finanze federali](/efv/it/home/finanzberichterstattung/bundeshaushalt_ueb.html "Panoramica delle finanze federali")
* [Rapporti finanziari](/efv/it/home/finanzberichterstattung/finanzberichte.html "Rapporti finanziari")
* [Dati](/efv/it/home/finanzberichterstattung/daten.html "Dati")






### L'AFF


* [Mandato](/efv/it/home/efv/auftrag.html "Mandato ")
* [Organizzazione](/efv/it/home/efv/organisation.html "Organizzazione")
* [Basi giuridiche](/efv/it/home/efv/rechtliche_grdl.html "Basi giuridiche ")
* [e\-fattura](/efv/it/home/efv/erechnung.html "e-fattura")
* [Contatto](/efv/it/home/efv/kontakt.html "Contatto")
* [Offerte d'impiego](/efv/it/home/efv/stellenangebote.html "Offerte d'impiego ")























### Rimanete informati



Social media links
* [LinkedIn](https://www.linkedin.com/company/72285581/admin/)









---


![Amministrazione federale delle finanze AFF](/efv/it/_jcr_content/logo/image.imagespooler.png/1675673515094/logo.png)




Amministrazione federale delle finanze AFF

* [Basi legali](https://www.admin.ch/gov/it/pagina-iniziale/basi-legali.html)



















