<!--
                                Source URL: https://www.efv.admin.ch/efv/en/home/efv/erechnung/aktuell.html
                                Page ID: 3
                                -->

                                





 

News








































* [Homepage](/efv/en/home.html)
* [Main navigation](#main-navigation)
* [Content area](#content)
* [Sitemap](#site-map)
* [Search](#search-field)








Federal Finance Administration
------------------------------


* [The Federal Council](#)
	+ [The Federal Council admin.ch](https://www.admin.ch/gov/en/start.html)
		- [FCh: Federal Chancellery](https://www.bk.admin.ch/bk/en/home.html)
		- [FDFA: Federal Department of Foreign Affairs](https://www.eda.admin.ch/eda/en/home.html)
		- [FDHA: Federal Department of Home Affairs](https://www.edi.admin.ch/edi/de/home.html)
		- [FDJP: Federal Department of Justice and Police](https://www.ejpd.admin.ch/content/ejpd/en/home.html)
		- [DDPS: Federal Department of Defence Civil Protection and Sport](https://www.vbs.admin.ch/en)
		- [FDF: Federal Department of Finance](https://www.efd.admin.ch/en)
		- [EAER: Federal Department of Economic Affairs, Education and Research](https://www.wbf.admin.ch/wbf/en/home.html)
		- [DETEC: Federal Department of the Environment, Transport, Energy and Communications](https://www.uvek.admin.ch/uvek/de/home.html)
* [FDF](#)
	+ [FDF: Federal Department of Finance](https://www.efd.admin.ch/en)
		- [GS\-FDF: The General Secretariat](https://www.efd.admin.ch/en/general-secretariat)
		- [SIF: State Secretary for International Financial](https://www.sif.admin.ch/sif/en/home.html)
		- [FFA: Federal Finance Administration](https://www.efv.admin.ch/efv/en/home.html)
		- [FOPER: Federal Personnel Office](https://www.epa.admin.ch/epa/de/home.html)
		- [FTA: Swiss Federal Tax Administration](https://www.estv.admin.ch/estv/en/home.html)
		- [FOCBS: Federal Office for Customs and Border Security](https://www.bazg.admin.ch/bazg/en/home.html)
		- [FOITT: Federal Office of Information Technology, Systems and Telecommunication](https://www.bit.admin.ch/bit/en/home.html)
		- [FBL: Federal Office for Buildings and Logistics](https://www.bbl.admin.ch/bbl/de/home.html)
		- [Federal Delegate for Plurilingualism](https://www.plurilingua.admin.ch/plurilingua/en/home.html)
		- [FINMA: Swiss Financial Market Supervisory Authority](https://www.finma.ch/en/)
		- [SFAO: Swiss Federal Audit Office](https://www.efk.admin.ch/index.php?lang=en)
		- [PUBLICA: Federal Pension Fund](https://publica.ch/en/home)
* [FFA](#)
	+ [Central Compensation Office CCO](https://www.zas.admin.ch/zas/en/home.html)
		- [Swissmint](https://www.swissmint.ch/en)





News
----


Languages
---------



* [DE](/efv/de/home/efv/erechnung/aktuell.html "German")
* [FR](/efv/fr/home/efv/erechnung/aktuell.html "French")
* [IT](/efv/it/home/efv/erechnung/aktuell.html "Italian")
* EN



Service navigation
------------------



* [Homepage](/efv/en/home.html "Homepage")
* [Contact](/efv/en/home/efv/kontakt.html "Contact")
* [Jobs](https://www.efv.admin.ch/efv/en/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/en/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)







[![Federal Finance Administration FFA](/efv/en/_jcr_content/logo/image.imagespooler.png/1675236487282/logo.png)
Federal Finance Administration FFA
----------------------------------](/efv/en/home.html "Homepage")





Search
------



















Main Navigation
---------------








![](/efv/en/_jcr_content/navigation/icon.imagespooler.png/1463575638314/swiss.png)

[FFA](/efv/en/home.html "Homepage")
-----------------------------------









* [Actuality](/efv/en/home/aktuell.html)


* [Topics](/efv/en/home/themen.html)


* [Financial reports](/efv/en/home/finanzberichterstattung.html)


* [The FFA](/efv/en/home/efv.html)















Search
------



















* [Actuality](/efv/en/home/aktuell.html)
	+ Close
* [Topics](/efv/en/home/themen.html)
	+ Close
* [Financial reports](/efv/en/home/finanzberichterstattung.html)
	+ Close
* [The FFAcurrent page](/efv/en/home/efv.html)
	+ Close









Breadcrumb
----------


1. [Homepage](/efv/en/home.html "Homepage")
2. [The FFA](/efv/en/home/efv.html "The FFA")
3. [E\-bill](/efv/en/home/efv/erechnung.html "E-bill")
4. News










[Unternavigation](#collapseSubNav)


[Zurück](/efv/en/home/efv.html)
[Zurück zu The FFA](/efv/en/home/efv.html)
* [E\-bill](/efv/en/home/efv/erechnung.html)
* News selected
* [Brief introduction](/efv/en/home/efv/erechnung/kurze-einfuehrung.html)
* [Submitting e\-bills to the Confederation](/efv/en/home/efv/erechnung/e-rechnung-zustellen.html)
* [Receiving e\-bills from the Confederation](/efv/en/home/efv/erechnung/e-rechnung-empfangen.html)
* [List of administrative units](/efv/en/home/efv/erechnung/liste-verwaltungseinheiten.html)










[Context sidebar](#context-sidebar)








News
====






![E-Rechnungs](/efv/en/home/efv/erechnung/aktuell/_jcr_content/par/textimage/image.imagespooler.jpg/1654590993616/original/erechnung.jpg)
Bill us \- but please electronically!
-------------------------------------





Bill us electronically
----------------------





Instead of printing your invoice and posting it to the Federal Administration, send your invoice data electronically to an e\-bill service provider. You can save time and money – we will process your invoices swiftly and seamlessly. Suppliers can submit invoices as structured e\-bills or as PDFs via various channels.


More information on:


[Submitting e\-bills to the Confederation](/efv/en/home/efv/erechnung/e-rechnung-zustellen.html)


[Receiving e\-bills from the Confederation](/efv/en/home/efv/erechnung/e-rechnung-empfangen.html)


If you have a question about a specific invoice, please contact the Shared Service Center Finances: [e\-rechnung@efv.admin.ch](mailto:e-rechnung@efv.admin.ch).





Proportion of e\-billing already over 75%
-----------------------------------------





The Confederation currently receives more than 75% of its invoices electronically. Since the Confederation obliged its suppliers to submit electronic invoices, the proportion of e\-bills has steadily risen from 18% in December 2014 to just over 75% in December 2021\. This corresponds to around 488,000 out of a total of 650,000 invoices per year. The obligation does not apply to all invoices, as small procurements are exempt.


Approximately 25% of outgoing invoices to external clients are issued electronically (structured e\-bills, PDF invoices via email). This meets a significant client need. The proportion is to be increased further.









Last modification 08\.06\.2022






[Top of page](#) 







Social share










#### Shopping cart














https://www.efv.admin.ch/content/efv/en/home/efv/erechnung/aktuell.html

Footer
------




### Federal Finance Administration FFA



* [Homepage](/efv/en/home.html "Homepage")
* [Contact](/efv/en/home/efv/kontakt.html "Contact")
* [Jobs](https://www.efv.admin.ch/efv/en/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/en/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)





Footer
------


[Sitemap](#site-map)



### Latest news


* [Press releases](/efv/en/home/aktuell/nsb-news_list.html "Press releases")
* [In focus](/efv/en/home/aktuell/brennpunkt.html "In focus")
* [Archive](/efv/en/home/aktuell/a.html "Archive")






### Topics


* [Financial policy, foundations](/efv/en/home/themen/finanzpolitik_grundlagen.html "Financial policy, foundations")
* [Financial statistics](/efv/en/home/themen/finanzstatistik.html "Financial statistics")
* [Fiscal Equalization](/efv/en/home/themen/finanzausgleich.html "Fiscal Equalization")
* [Funding, asset and liability management](/efv/en/home/themen/mittelbeschaff_verm_schuldenverw.html "Funding, asset and liability management")
* [Monetary and currency system](/efv/en/home/themen/waehrung_gewinnaussch_int.html "Monetary and currency system")
* [Projects](/efv/en/home/themen/projekte.html "Projects")
* [Publications](/efv/en/home/themen/publikationen.html "Publications")






### Financial reports


* [Federal finances at a glance](/efv/en/home/finanzberichterstattung/bundeshaushalt_ueb.html "Federal finances at a glance")
* [Financial reports](/efv/en/home/finanzberichterstattung/finanzberichte.html "Financial reports")
* [Data](/efv/en/home/finanzberichterstattung/daten.html "Data")






### The FFA


* [Task](/efv/en/home/efv/auftrag.html "Task")
* [E\-bill](/efv/en/home/efv/erechnung.html "E-bill")
* [Organisation](/efv/en/home/efv/organisation.html "Organisation")
* [Contact](/efv/en/home/efv/kontakt.html "Contact")
* [Jobs](/efv/en/home/efv/stellenangebote.html "Jobs")























### Stay informed



Social media links
* [LinkedIn](https://www.linkedin.com/company/72285581/admin/)









---


![Federal Finance Administration FFA](/efv/en/_jcr_content/logo/image.imagespooler.png/1675236487282/logo.png)




Federal Finance Administration FFA

* [Legal framework](https://www.admin.ch/gov/en/start/terms-and-conditions.html)



















