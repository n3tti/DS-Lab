<!--
                                Source URL: https://www.efv.admin.ch/efv/de/home/efv/erechnung/e-rechnung-empfangen.html
                                Page ID: 10
                                -->

                                





 

E\-Rechnungen vom Bund empfangen








































* [Homepage](/efv/de/home.html)
* [Main navigation](#main-navigation)
* [Content area](#content)
* [Sitemap](#site-map)
* [Search](#search-field)








Eidgenössische Finanzverwaltung
-------------------------------


* [Der Bundesrat](#)
	+ [Der Bundesrat admin.ch](https://www.admin.ch/gov/de/start.html)
		- [BK: Schweizerische Bundeskanzlei](https://www.bk.admin.ch/bk/de/home.html)
		- [EDA: Eidgenössisches Departement für auswärtige Angelegenheiten](https://www.eda.admin.ch/eda/de/home.html)
		- [EDI: Eidgenössisches Departement des Innern](http://www.edi.admin.ch/)
		- [EJPD: Eidgenössisches Justiz\- und Polizeidepartement](http://www.ejpd.admin.ch/ejpd/de/home.html)
		- [VBS: Eidgenössisches Departement für Verteidigung, Bevölkerungsschutz und Sport](https://www.vbs.admin.ch/de)
		- [EFD: Eidgenössisches Finanzdepartement](https://www.efd.admin.ch/de)
		- [WBF: Eidgenössisches Departement für Wirtschaft, Bildung und Forschung](https://www.wbf.admin.ch/wbf/de/home.html)
		- [UVEK: Eidgenössiches Departement für Umwelt, Verkehr, Energie und Kommunikation](https://www.uvek.admin.ch/uvek/de/home.html)
* [EFD](#)
	+ [EFD: Eidgenössisches Finanzdepartement](https://www.efd.admin.ch/de)
		- [GS\-EFD: Generalsekretariat](https://www.efd.admin.ch/de/generalsekretariat)
		- [SIF: Staatssekretariat für internationale Finanzfragen](https://www.sif.admin.ch/sif/de/home.html)
		- [EFV: Eidgenössische Finanzverwaltung](https://www.efv.admin.ch/efv/de/home.html)
		- [EPA: Eidgenössisches Personalamt](https://www.epa.admin.ch/epa/de/home.html)
		- [ESTV: Eidgenössische Steuerverwaltung](https://www.estv.admin.ch/estv/de/home.html)
		- [BAZG: Bundesamt für Zoll und Grenzsicherheit](https://www.bazg.admin.ch/bazg/de/home.html)
		- [BIT: Bundesamt für Informatik und Telekommunikation](https://www.bit.admin.ch/bit/de/home.html)
		- [BBL: Bundesamt für Bauten und Logistik](https://www.bbl.admin.ch/bbl/de/home.html)
		- [Delegierte des Bundes für Mehrsprachigkeit](https://www.plurilingua.admin.ch/plurilingua/de/home.html)
		- [FINMA: Eidgenössische Finanzmarktaufsicht](https://www.finma.ch/de/)
		- [EFK: Eidgenössischen Finanzkontrolle](http://www.efk.admin.ch/index.php?lang=de)
		- [PUBLICA: Pensionskasse des Bundes](https://publica.ch/)
* [EFV](#)
	+ [Zentrale Ausgleichsstelle ZAS](https://www.zas.admin.ch/zas/de/home.html)
		- [Swissmint](http://www.swissmint.ch/)





E\-Rechnungen vom Bund empfangen
--------------------------------



* DE
* [FR](/efv/fr/home/efv/erechnung/e-rechnung-empfangen.html "Französisch")
* [IT](/efv/it/home/efv/erechnung/e-rechnung-empfangen.html "Italienisch")
* [EN](/efv/en/home/efv/erechnung/e-rechnung-empfangen.html "Englisch")



Service navigation
------------------



* [Startseite](/efv/de/home.html "Startseite")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellen](https://www.efv.admin.ch/efv/de/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/de/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)







[![Eidgenössische Finanzverwaltung EFV](/efv/de/_jcr_content/logo/image.imagespooler.png/1675236523651/logo.png)
Eidgenössische Finanzverwaltung EFV
-----------------------------------](/efv/de/home.html "Startseite")





Suche
-----



















Hauptnavigation
---------------








![Eidgenössische Finanzverwaltung EFV](/etc/designs/core/frontend/guidelines/img/swiss.svg)

[EFV](/efv/de/home.html "Startseite")
-------------------------------------









* [Aktuell](/efv/de/home/aktuell.html)


* [Themen](/efv/de/home/themen.html)


* [Finanzberichte](/efv/de/home/finanzberichterstattung.html)


* [Die EFV](/efv/de/home/efv.html)















Suche
-----



















* [Aktuell](/efv/de/home/aktuell.html)
	+ Schliessen
* [Themen](/efv/de/home/themen.html)
	+ Schliessen
* [Finanzberichte](/efv/de/home/finanzberichterstattung.html)
	+ Schliessen
* [Die EFVcurrent page](/efv/de/home/efv.html)
	+ Schliessen









Breadcrumb
----------


1. [Startseite](/efv/de/home.html "Startseite")
2. [Die EFV](/efv/de/home/efv.html "Die EFV")
3. [E\-Rechnung](/efv/de/home/efv/erechnung.html "E-Rechnung")
4. E\-Rechnungen vom Bund empfangen










[Unternavigationen](#collapseSubNav)


[Zurück](/efv/de/home/efv.html)
[Zurück Die EFV](/efv/de/home/efv.html)
* [E\-Rechnung](/efv/de/home/efv/erechnung.html)
* [Aktuell](/efv/de/home/efv/erechnung/aktuell.html)
* [Kurze Einführung](/efv/de/home/efv/erechnung/kurze-einfuehrung.html)
* [E\-Rechnungen dem Bund zustellen](/efv/de/home/efv/erechnung/e-rechnung-zustellen.html)
* E\-Rechnungen vom Bund empfangen selected
* [Liste Verwaltungseinheiten](/efv/de/home/efv/erechnung/liste-verwaltungseinheiten.html)










[Zum Seitenende](#context-sidebar)








E\-Rechnungen vom Bund empfangen
================================





PDF\-Rechnungen per E\-Mail
---------------------------





Als Rechnungsempfänger/in der Bundesverwaltung haben Sie die Möglichkeit, sich für den Empfang von PDF\-Rechnungen per E\-Mail zu registrieren.


[Anmeldung für den Empfang von PDF\-Rechnungen per E\-Mail](/efv/de/home/efv/erechnung/pdf-rg-mail.html)





Strukturierte E\-Rechnungen
---------------------------





Mit der E\-Rechnung erhalten Sie als Privatperson oder Geschäftskunde die Rechnung von der Bundesverwaltung elektronisch und papierlos.


Als Geschäftskunde können Sie die E\-Rechnungen direkt im Online\-Banking Ihres Finanzinstitutes bearbeiten oder über verschiedene Kanäle in Ihre Finanzsoftware importieren und dort weiterverarbeiten.


Die Liste der Verwaltungseinheiten, die Ihnen die Rechnung elektronisch zustellen können, finden Sie auf dieser Seite unter dem Verzeichnis «Liste der E\-Rechnungssteller».





Vorgehen Privatkunden
---------------------





Als Privatkunde erhalten Sie die E\-Rechnung direkt über den Online\-Banking\-Service Ihres Finanzinstituts.


#### Voraussetzungen, erste Schritte


* Sie benötigen einen Online\-Banking\-Vertrag bei einem Finanzinstitut in der Schweiz, wobei das E\-Banking die E\-Rechnung unterstützen muss.
* Loggen Sie sich ins Online\-Banking ein und gehen Sie zur Funktion E\-Rechnung.
* Falls Sie bisher noch keine E\-Rechnungen empfangen, melden Sie sich zuerst für die Teilnahme an der E\-Rechnung an. Erst dann können Sie sich bei Ihren Rechnungsstellern für die E\-Rechnung registrieren.
* Wählen Sie in der Liste der Rechnungssteller die gewünschte Verwaltungseinheit des Bundes aus, um sich anzumelden.
* In der Registriermaske erfassen Sie Ihre persönlichen Daten und geben Ihre Kundennummer an.
* Ihre Kundennummer finden Sie in der Regel auf der bisherigen Papierrechnung ([Beispielrechnung (PDF, 85 kB, 07\.07\.2022\)](/dam/efv/de/dokumente/efv/E-Rechnung/beispielrechnung.pdf.download.pdf/Beispielrechnung_d.pdf "Beispielrechnung")). Kontaktieren Sie den Rechnungssteller, falls Sie nicht fündig werden.





Vorgehen Geschäftskunden
------------------------





Als Geschäftskundin oder Geschäftskunde haben Sie zwei Möglichkeiten, die Rechnungen elektronisch zu erhalten: direkt in Ihr Buchhaltungssystem oder ins Online\-Banking.


#### Online\-Banking


Nutzen Sie die Möglichkeiten wie Privatkunden. Bitte beachten Sie, dass Geschäftskunden zusätzlich einen E\-Rechnungsvertrag mit Ihrem Finanzinstitut benötigen.


#### Buchhaltungssystem


Geschäftskundinnen und \-kunden können die strukturierten und digital signierten Rechnungsdaten elektronisch in ihr Buchhaltungssystem übernehmen. Dadurch können interne Prozesse wie Visierung, Freigabe oder Archivierung vollständig automatisiert werden. Dies führt gegenüber den klassischen Bearbeitungsprozessen zu verkürzten Durchlaufzeiten und höherer Datenqualität. Das Begleichen der Rechnungen erfolgt über die bisher genutzten Zahlungskanäle.


#### Voraussetzungen, erste Schritte


* Stellen Sie in Ihrem Unternehmen die technischen Voraussetzungen für den Empfang, die Verarbeitung und die Archivierung von E\-Rechnungen im Buchhaltungssystem bereit. Zum Empfangen der E\-Rechnung benötigen Sie einen Vertrag mit einem Dienstleister für E\-Rechnungen. Informieren Sie sich hierzu bei Ihrem Finanzinstitut und bei [swissDIGIN](http://www.swissdigin.ch/) (Forum zur Förderung der elektronischen Rechnung im Business\-to\-Business).
* Mit dem Vertrag erhalten Sie eine Teilnehmernummer
* Teilen Sie den Rechnungsstellern diese Teilnehmernummer zusammen mit Ihrer Kundennummer mit und verlangen Sie die E\-Rechnung.
* Nachdem die Übermittlung der E\-Rechnung eingerichtet und getestet ist, erhalten Sie Ihre mehrwertsteuerkonformen Rechnungen elektronisch und können sie direkt in Ihr Buchhaltungssystem übernehmen.
* Der Prozess für die Überweisung der Zahlung wird durch die E\-Rechnung nicht verändert.
* Ihre Kundennummer finden Sie in der Regel auf der bisherigen Papierrechnung ([Beispielrechnung (PDF, 85 kB, 07\.07\.2022\)](/dam/efv/de/dokumente/efv/E-Rechnung/beispielrechnung.pdf.download.pdf/Beispielrechnung_d.pdf "Beispielrechnung")). Kontaktieren Sie den Rechnungssteller, falls Sie nicht fündig werden.


In der [Liste Verwaltungseinheiten](/efv/de/home/efv/erechnung/liste-verwaltungseinheiten.html) sind alle Stellen der schweizerischen Bundesverwaltung aufgeführt, die E\-Rechnungen versenden.


Die Schweizer Finanzinstitute betreiben gemeinsam die Internet\-Seite  [www.ebill.ch](https://www.ebill.ch/). Auf dieser finden Sie – neben vielen anderen nützlichen Hinweisen zur E\-Rechnung – eine aktuelle Liste aller E\-Rechnungssteller in der Schweiz.  




Das E\-Invoicing\-Teilnehmerverzeichnis [eDirectory.ch](http://www.edirectory.ch/) führt in der Schweiz domizilierte Unternehmen und Organisationen auf, die mit ihren Geschäftspartnern Rechnungen in strukturierter, elektronischer Form austauschen wollen.









Letzte Änderung 09\.06\.2022






[Zum Seitenanfang](#) 







Social share










#### Einkaufskorb














https://www.efv.admin.ch/content/efv/de/home/efv/erechnung/e\-rechnung\-empfangen.html

Footer
------




### Eidgenössische Finanzverwaltung EFV



* [Startseite](/efv/de/home.html "Startseite")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellen](https://www.efv.admin.ch/efv/de/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/de/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)





Footer
------


[Sitemap](#site-map)



### Aktuell


* [Medienmitteilungen](/efv/de/home/aktuell/nsb-news_list.html "Medienmitteilungen")
* [Im Brennpunkt](/efv/de/home/aktuell/brennpunkt.html "Im Brennpunkt")
* [Archiv](/efv/de/home/aktuell/a.html "Archiv")






### Themen


* [Finanzpolitik, Grundlagen](/efv/de/home/themen/finanzpolitik_grundlagen.html "Finanzpolitik, Grundlagen")
* [Finanzstatistik](/efv/de/home/themen/finanzstatistik.html "Finanzstatistik")
* [Finanzausgleich](/efv/de/home/themen/finanzausgleich.html "Finanzausgleich")
* [Mittelbeschaffung, Vermögens\- und Schuldenverwaltung](/efv/de/home/themen/mittelbeschaff_verm_schuldenverw.html "Mittelbeschaffung, Vermögens- und Schuldenverwaltung")
* [Geld\- und Währungsordnung](/efv/de/home/themen/waehrung_gewinnaussch_int.html "Geld- und Währungsordnung")
* [Projekte](/efv/de/home/themen/projekte.html "Projekte")
* [Publikationen](/efv/de/home/themen/publikationen.html "Publikationen")






### Finanzberichte


* [Bundeshaushalt im Überblick](/efv/de/home/finanzberichterstattung/bundeshaushalt_ueb.html "Bundeshaushalt im Überblick")
* [Finanzberichte](/efv/de/home/finanzberichterstattung/finanzberichte.html "Finanzberichte")
* [Daten](/efv/de/home/finanzberichterstattung/daten.html "Daten")






### Die EFV


* [Auftrag](/efv/de/home/efv/auftrag.html "Auftrag")
* [Organisation](/efv/de/home/efv/organisation.html "Organisation")
* [Rechtliche Grundlagen](/efv/de/home/efv/rechtliche_grdl.html "Rechtliche Grundlagen")
* [E\-Rechnung](/efv/de/home/efv/erechnung.html "E-Rechnung")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellenangebote](/efv/de/home/efv/stellenangebote.html "Stellenangebote")























### Informiert bleiben



Social media links
* [LinkedIn](https://www.linkedin.com/company/72285581/admin/)









---


![Logo der Schweiz](/efv/de/_jcr_content/copyright/image.imagespooler.png/1694447418949/logo.png)




Eidgenössische Finanzverwaltung EFV

* [Rechtliches](https://www.admin.ch/gov/de/start/rechtliches.html)



















