<!--
                                Source URL: https://www.efv.admin.ch/efv/de/home/efv/kontakt.html
                                Page ID: 8
                                -->

                                





 

Kontakt











































* [Homepage](/efv/de/home.html)
* [Main navigation](#main-navigation)
* [Content area](#content)
* [Sitemap](#site-map)
* [Search](#search-field)








Eidgenössische Finanzverwaltung
-------------------------------


* [Der Bundesrat](#)
	+ [Der Bundesrat admin.ch](https://www.admin.ch/gov/de/start.html)
		- [BK: Schweizerische Bundeskanzlei](https://www.bk.admin.ch/bk/de/home.html)
		- [EDA: Eidgenössisches Departement für auswärtige Angelegenheiten](https://www.eda.admin.ch/eda/de/home.html)
		- [EDI: Eidgenössisches Departement des Innern](http://www.edi.admin.ch/)
		- [EJPD: Eidgenössisches Justiz\- und Polizeidepartement](http://www.ejpd.admin.ch/ejpd/de/home.html)
		- [VBS: Eidgenössisches Departement für Verteidigung, Bevölkerungsschutz und Sport](https://www.vbs.admin.ch/de)
		- [EFD: Eidgenössisches Finanzdepartement](https://www.efd.admin.ch/de)
		- [WBF: Eidgenössisches Departement für Wirtschaft, Bildung und Forschung](https://www.wbf.admin.ch/wbf/de/home.html)
		- [UVEK: Eidgenössiches Departement für Umwelt, Verkehr, Energie und Kommunikation](https://www.uvek.admin.ch/uvek/de/home.html)
* [EFD](#)
	+ [EFD: Eidgenössisches Finanzdepartement](https://www.efd.admin.ch/de)
		- [GS\-EFD: Generalsekretariat](https://www.efd.admin.ch/de/generalsekretariat)
		- [SIF: Staatssekretariat für internationale Finanzfragen](https://www.sif.admin.ch/sif/de/home.html)
		- [EFV: Eidgenössische Finanzverwaltung](https://www.efv.admin.ch/efv/de/home.html)
		- [EPA: Eidgenössisches Personalamt](https://www.epa.admin.ch/epa/de/home.html)
		- [ESTV: Eidgenössische Steuerverwaltung](https://www.estv.admin.ch/estv/de/home.html)
		- [BAZG: Bundesamt für Zoll und Grenzsicherheit](https://www.bazg.admin.ch/bazg/de/home.html)
		- [BIT: Bundesamt für Informatik und Telekommunikation](https://www.bit.admin.ch/bit/de/home.html)
		- [BBL: Bundesamt für Bauten und Logistik](https://www.bbl.admin.ch/bbl/de/home.html)
		- [Delegierte des Bundes für Mehrsprachigkeit](https://www.plurilingua.admin.ch/plurilingua/de/home.html)
		- [FINMA: Eidgenössische Finanzmarktaufsicht](https://www.finma.ch/de/)
		- [EFK: Eidgenössischen Finanzkontrolle](http://www.efk.admin.ch/index.php?lang=de)
		- [PUBLICA: Pensionskasse des Bundes](https://publica.ch/)
* [EFV](#)
	+ [Zentrale Ausgleichsstelle ZAS](https://www.zas.admin.ch/zas/de/home.html)
		- [Swissmint](http://www.swissmint.ch/)





Kontakt
-------



* DE
* [FR](/efv/fr/home/efv/kontakt.html "Französisch")
* [IT](/efv/it/home/efv/kontakt.html "Italienisch")
* [EN](/efv/en/home/efv/kontakt.html "Englisch")



Service navigation
------------------



* [Startseite](/efv/de/home.html "Startseite")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellen](https://www.efv.admin.ch/efv/de/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/de/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)







[![Eidgenössische Finanzverwaltung EFV](/efv/de/_jcr_content/logo/image.imagespooler.png/1675236523651/logo.png)
Eidgenössische Finanzverwaltung EFV
-----------------------------------](/efv/de/home.html "Startseite")





Suche
-----



















Hauptnavigation
---------------








![Eidgenössische Finanzverwaltung EFV](/etc/designs/core/frontend/guidelines/img/swiss.svg)

[EFV](/efv/de/home.html "Startseite")
-------------------------------------









* [Aktuell](/efv/de/home/aktuell.html)


* [Themen](/efv/de/home/themen.html)


* [Finanzberichte](/efv/de/home/finanzberichterstattung.html)


* [Die EFV](/efv/de/home/efv.html)















Suche
-----



















* [Aktuell](/efv/de/home/aktuell.html)
	+ Schliessen
* [Themen](/efv/de/home/themen.html)
	+ Schliessen
* [Finanzberichte](/efv/de/home/finanzberichterstattung.html)
	+ Schliessen
* [Die EFVcurrent page](/efv/de/home/efv.html)
	+ Schliessen









Breadcrumb
----------


1. [Startseite](/efv/de/home.html "Startseite")
2. [Die EFV](/efv/de/home/efv.html "Die EFV")
3. Kontakt










[Unternavigationen](#collapseSubNav)


[Zurück](/efv/de/home.html)
[Zurück Startseite](/efv/de/home.html)
* [Die EFV](/efv/de/home/efv.html)
* [Auftrag](/efv/de/home/efv/auftrag.html)
* [Organisation](/efv/de/home/efv/organisation.html)
* [Rechtliche Grundlagen](/efv/de/home/efv/rechtliche_grdl.html)
* [E\-Rechnung](/efv/de/home/efv/erechnung.html)
* Kontakt selected
* [Stellenangebote](/efv/de/home/efv/stellenangebote.html)










[Zum Seitenende](#context-sidebar)








Kontakt
=======










 
 
 Diese e\-Mail konnte nicht versendet werden.
 
 
 
 













Themen: 

Allgemeine Fragen
 Zahlungsverkehr
 








Frage 









Name: 








Email \*














 **Eidg. Finanzverwaltung EFV**  

Bundesgasse 3  

3003 Bern  

Schweiz


Tel. [\+41 58 462 21 11](tel:0041584622111) (Telefonzentrale Bundesverwaltung)  

Fax \+41 58 462 61 87






[info@efv.admin.ch](mailto:info@efv.admin.ch "info@efv.admin.ch")






**Medienanfragen**Kommunikation EFV


Philipp Rohr, Leitung  

Michael Girod, Mediensprecher  

Sarah Pfäffli, Mediensprecherin


Tel. [\+41 58 465 16 06](tel:0041584651606)






[kommunikation@efv.admin.ch](mailto:kommunikation@efv.admin.ch "kommunikation@efv.admin.ch")






[Die EFV auf LinkedIn](https://www.linkedin.com/company/72285581/admin/)






### Aktuell


[Medienmitteilungen der EFV](/efv/de/home/aktuell/nsb-news_list.html)





Gesuche um Einsichtnahme nach Öffentlichkeitsgesetz
---------------------------------------------------





Im Bundesgesetz über die Öffentlichkeit der Verwaltung und in der zugehörigen Ausführungsverordnung ist das «Öffentlichkeitsprinzip mit Geheimhaltungsvorbehalt» festgehalten. Demnach hat jede Person das Recht auf Zugang zu amtlichen Dokumenten, die nach Inkrafttreten des Gesetzes fertiggestellt wurden. Sie braucht dazu kein besonderes Interesse nachzuweisen.


Anfragen müssen so formuliert sein, dass die zuständige Behörde die gewünschten Dokumente ermitteln kann. Zu diesem Zweck sollten möglichst viele Angaben über das Dokument gemacht werden – wie Datum, Titel, Referenznummer, Zeitraum, besonderes Ereignis, Sachbereich, erstellende oder empfangende Behörde und weitere betroffene Behörden. Die Einsicht in Dokumente kann zum Schutz überwiegender öffentlicher oder privater Interessen eingeschränkt oder verweigert werden.


Die Bearbeitung des Gesuchs ist gebührenpflichtig; bei geringem Aufwand werden die Gebühren allerdings erlassen.


**Adresse zur Einreichung von Gesuchen**


Eidgenössische Finanzverwaltung EFV  

Einsichtsgesuche Öffentlichkeitsgesetz  

Bundesgasse 3  

3003 Bern


[info@efv.admin.ch](mailto:info@efv.admin.ch), Betreff: Einsichtsgesuch Öffentlichkeitsgesetz





Lagepläne Eidgenössische Finanzverwaltung EFV
---------------------------------------------




### Monbijoustrasse 118







[Routenplaner (Google Maps) Monbijoustrasse 118](https://goo.gl/maps/8DN8qDu2Zdv5jc7x9)





[Lageplan EFV (Monbijoustrasse) (PDF, 202 kB, 13\.08\.2015\)](/dam/efv/de/dokumente/efv/lageplaene/Situationsplan_EFV_MO_d.pdf.download.pdf/Situationsplan_EFV_MO_d.pdf "Lageplan EFV (Monbijoustrasse)")





### Bernerhof, Bundesgasse 3







[Routenplaner (Google Maps) Bernerhof, Bundesgasse 3](https://goo.gl/maps/yq4cd8ubYJxxgzWX8)





[Lageplan EFV (Bernerhof) (PDF, 677 kB, 13\.08\.2015\)](/dam/efv/de/dokumente/efv/lageplaene/lageplan_efv.pdf.download.pdf/Situationsplan_EFV_d.pdf "Lageplan EFV (Bernerhof)")







* [Externe Links](#externe_links__content_efv_de_home_efv_kontakt_jcr_content_par_tabs)





Externe Links
-------------




[EFD: Eidgenössisches Finanzdepartement](https://www.efd.admin.ch/de)






[Swissmint](https://www.swissmint.ch/de)






[Zentrale Ausgleichsstelle ZAS](https://www.zas.admin.ch/zas/de/home.html)






[Öffentlichkeitsgesetz BGÖ](https://www.admin.ch/opc/de/classified-compilation/20022540/index.html)






[Öffentlichkeitsverordnung VBGÖ](https://www.admin.ch/opc/de/classified-compilation/20051874/index.html)












Letzte Änderung 14\.11\.2024






[Zum Seitenanfang](#) 







Social share









#### Einkaufskorb














https://www.efv.admin.ch/content/efv/de/home/efv/kontakt.html

Footer
------



### Eidgenössische Finanzverwaltung EFV



* [Startseite](/efv/de/home.html "Startseite")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellen](https://www.efv.admin.ch/efv/de/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/de/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)





Footer
------


[Sitemap](#site-map)



### Aktuell


* [Medienmitteilungen](/efv/de/home/aktuell/nsb-news_list.html "Medienmitteilungen")
* [Im Brennpunkt](/efv/de/home/aktuell/brennpunkt.html "Im Brennpunkt")
* [Archiv](/efv/de/home/aktuell/a.html "Archiv")






### Themen


* [Finanzpolitik, Grundlagen](/efv/de/home/themen/finanzpolitik_grundlagen.html "Finanzpolitik, Grundlagen")
* [Finanzstatistik](/efv/de/home/themen/finanzstatistik.html "Finanzstatistik")
* [Finanzausgleich](/efv/de/home/themen/finanzausgleich.html "Finanzausgleich")
* [Mittelbeschaffung, Vermögens\- und Schuldenverwaltung](/efv/de/home/themen/mittelbeschaff_verm_schuldenverw.html "Mittelbeschaffung, Vermögens- und Schuldenverwaltung")
* [Geld\- und Währungsordnung](/efv/de/home/themen/waehrung_gewinnaussch_int.html "Geld- und Währungsordnung")
* [Projekte](/efv/de/home/themen/projekte.html "Projekte")
* [Publikationen](/efv/de/home/themen/publikationen.html "Publikationen")






### Finanzberichte


* [Bundeshaushalt im Überblick](/efv/de/home/finanzberichterstattung/bundeshaushalt_ueb.html "Bundeshaushalt im Überblick")
* [Finanzberichte](/efv/de/home/finanzberichterstattung/finanzberichte.html "Finanzberichte")
* [Daten](/efv/de/home/finanzberichterstattung/daten.html "Daten")






### Die EFV


* [Auftrag](/efv/de/home/efv/auftrag.html "Auftrag")
* [Organisation](/efv/de/home/efv/organisation.html "Organisation")
* [Rechtliche Grundlagen](/efv/de/home/efv/rechtliche_grdl.html "Rechtliche Grundlagen")
* [E\-Rechnung](/efv/de/home/efv/erechnung.html "E-Rechnung")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellenangebote](/efv/de/home/efv/stellenangebote.html "Stellenangebote")























### Informiert bleiben



Social media links
* [LinkedIn](https://www.linkedin.com/company/72285581/admin/)









---


![Logo der Schweiz](/efv/de/_jcr_content/copyright/image.imagespooler.png/1694447418949/logo.png)




Eidgenössische Finanzverwaltung EFV

* [Rechtliches](https://www.admin.ch/gov/de/start/rechtliches.html)



















