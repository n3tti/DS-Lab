<!--
                                Source URL: https://eportal.admin.ch
                                Page ID: 5
                                -->

                                






ePortal







**JavaScript ist erforderlich!**

 Bitte aktivieren Sie JavaScript, da es für die Ausführung dieser
 Anwendung erforderlich ist.
 




**JavaScript est nécessaire!**

 Veuillez activer JavaScript car il est nécessaire pour le
 fonctionnement de cette application.
 




**JavaScript è richiesto!**

 Si prega di attivare JavaScript perché è necessario per l'esecuzione
 di questa applicazione.
 




**JavaScript is required!**

 Please activate JavaScript as it is required for this application to
 run.
 








**Nicht unterstützter Browser!**

 Einige Funktionen, die für die Ausführung dieser Anwendung
 erforderlich sind, werden von Ihrem Browser nicht unterstützt.
 



 Bitte beachten Sie, dass die Schweizerische Eidgenossenschaft nur
 Chrome, Firefox, Edge und Safari in ihren jeweils 2 letzten
 Versionen unterstützt.
 




**Navigateur non pris en charge!**

 Certaines fonctionnalités nécessaires au fonctionnement de cette
 application ne sont pas prises en charge par votre navigateur.
 



 Veuillez noter que la Confédération suisse ne supporte que Chrome,
 Firefox, Edge et Safari dans leurs 2 dernières versions respectives.
 




**Browser non supportato!**

 Alcune funzioni necessarie per il funzionamento di questa
 applicazione non sono supportate dal tuo browser.
 



 Si prega di notare che la Confederazione Svizzera supporta solo
 Chrome, Firefox, Edge e Safari nelle loro rispettive ultime 2
 versioni.
 




**Unsupported browser!**

 Some features required for this application to run are not supported
 by your browser.
 



 Please note that the Swiss Confederation only supports Chrome,
 Firefox, Edge and Safari in their respective latest 2 versions.
 








