<!--
                                Source URL: https://www.efv.admin.ch/efv/de/home/efv.html
                                Page ID: 6
                                -->

                                





 

Die EFV










































* [Homepage](/efv/de/home.html)
* [Main navigation](#main-navigation)
* [Content area](#content)
* [Sitemap](#site-map)
* [Search](#search-field)








Eidgenössische Finanzverwaltung
-------------------------------


* [Der Bundesrat](#)
	+ [Der Bundesrat admin.ch](https://www.admin.ch/gov/de/start.html)
		- [BK: Schweizerische Bundeskanzlei](https://www.bk.admin.ch/bk/de/home.html)
		- [EDA: Eidgenössisches Departement für auswärtige Angelegenheiten](https://www.eda.admin.ch/eda/de/home.html)
		- [EDI: Eidgenössisches Departement des Innern](http://www.edi.admin.ch/)
		- [EJPD: Eidgenössisches Justiz\- und Polizeidepartement](http://www.ejpd.admin.ch/ejpd/de/home.html)
		- [VBS: Eidgenössisches Departement für Verteidigung, Bevölkerungsschutz und Sport](https://www.vbs.admin.ch/de)
		- [EFD: Eidgenössisches Finanzdepartement](https://www.efd.admin.ch/de)
		- [WBF: Eidgenössisches Departement für Wirtschaft, Bildung und Forschung](https://www.wbf.admin.ch/wbf/de/home.html)
		- [UVEK: Eidgenössiches Departement für Umwelt, Verkehr, Energie und Kommunikation](https://www.uvek.admin.ch/uvek/de/home.html)
* [EFD](#)
	+ [EFD: Eidgenössisches Finanzdepartement](https://www.efd.admin.ch/de)
		- [GS\-EFD: Generalsekretariat](https://www.efd.admin.ch/de/generalsekretariat)
		- [SIF: Staatssekretariat für internationale Finanzfragen](https://www.sif.admin.ch/sif/de/home.html)
		- [EFV: Eidgenössische Finanzverwaltung](https://www.efv.admin.ch/efv/de/home.html)
		- [EPA: Eidgenössisches Personalamt](https://www.epa.admin.ch/epa/de/home.html)
		- [ESTV: Eidgenössische Steuerverwaltung](https://www.estv.admin.ch/estv/de/home.html)
		- [BAZG: Bundesamt für Zoll und Grenzsicherheit](https://www.bazg.admin.ch/bazg/de/home.html)
		- [BIT: Bundesamt für Informatik und Telekommunikation](https://www.bit.admin.ch/bit/de/home.html)
		- [BBL: Bundesamt für Bauten und Logistik](https://www.bbl.admin.ch/bbl/de/home.html)
		- [Delegierte des Bundes für Mehrsprachigkeit](https://www.plurilingua.admin.ch/plurilingua/de/home.html)
		- [FINMA: Eidgenössische Finanzmarktaufsicht](https://www.finma.ch/de/)
		- [EFK: Eidgenössischen Finanzkontrolle](http://www.efk.admin.ch/index.php?lang=de)
		- [PUBLICA: Pensionskasse des Bundes](https://publica.ch/)
* [EFV](#)
	+ [Zentrale Ausgleichsstelle ZAS](https://www.zas.admin.ch/zas/de/home.html)
		- [Swissmint](http://www.swissmint.ch/)





Die EFV
-------



* DE
* [FR](/efv/fr/home/efv.html "Französisch")
* [IT](/efv/it/home/efv.html "Italienisch")
* [EN](/efv/en/home/efv.html "Englisch")



Service navigation
------------------



* [Startseite](/efv/de/home.html "Startseite")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellen](https://www.efv.admin.ch/efv/de/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/de/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)







[![Eidgenössische Finanzverwaltung EFV](/efv/de/_jcr_content/logo/image.imagespooler.png/1675236523651/logo.png)
Eidgenössische Finanzverwaltung EFV
-----------------------------------](/efv/de/home.html "Startseite")





Suche
-----



















Hauptnavigation
---------------








![Eidgenössische Finanzverwaltung EFV](/etc/designs/core/frontend/guidelines/img/swiss.svg)

[EFV](/efv/de/home.html "Startseite")
-------------------------------------









* [Aktuell](/efv/de/home/aktuell.html)


* [Themen](/efv/de/home/themen.html)


* [Finanzberichte](/efv/de/home/finanzberichterstattung.html)


* [Die EFV](/efv/de/home/efv.html)















Suche
-----



















* [Aktuell](/efv/de/home/aktuell.html)
	+ Schliessen
* [Themen](/efv/de/home/themen.html)
	+ Schliessen
* [Finanzberichte](/efv/de/home/finanzberichterstattung.html)
	+ Schliessen
* [Die EFVcurrent page](/efv/de/home/efv.html)
	+ Schliessen









Breadcrumb
----------


1. [Startseite](/efv/de/home.html "Startseite")
2. Die EFV










[Zum Seitenende](#context-sidebar)






### [Auftrag](/efv/de/home/efv/auftrag.html "Auftrag")


### [Organisation](/efv/de/home/efv/organisation.html "Organisation")


* [Organigramm](/efv/de/home/efv/organisation/organigramm.html "Organigramm")
* [Leitung](/efv/de/home/efv/organisation/leitung.html "Leitung")




### [Rechtliche Grundlagen](/efv/de/home/efv/rechtliche_grdl.html "Rechtliche Grundlagen")




### [E\-Rechnung](/efv/de/home/efv/erechnung.html "E-Rechnung")


* [Aktuell](/efv/de/home/efv/erechnung/aktuell.html "Aktuell")
* [Kurze Einführung](/efv/de/home/efv/erechnung/kurze-einfuehrung.html "Kurze Einführung")
* [E\-Rechnungen dem Bund zustellen](/efv/de/home/efv/erechnung/e-rechnung-zustellen.html "E-Rechnungen dem Bund zustellen ")
* [E\-Rechnungen vom Bund empfangen](/efv/de/home/efv/erechnung/e-rechnung-empfangen.html "E-Rechnungen vom Bund empfangen")
* [Liste Verwaltungseinheiten](/efv/de/home/efv/erechnung/liste-verwaltungseinheiten.html "Liste Verwaltungseinheiten")




### [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")


### [Stellenangebote](/efv/de/home/efv/stellenangebote.html "Stellenangebote")









https://www.efv.admin.ch/content/efv/de/home/efv.html

Footer
------




### Eidgenössische Finanzverwaltung EFV



* [Startseite](/efv/de/home.html "Startseite")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellen](https://www.efv.admin.ch/efv/de/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/de/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)





Footer
------


[Sitemap](#site-map)



### Aktuell


* [Medienmitteilungen](/efv/de/home/aktuell/nsb-news_list.html "Medienmitteilungen")
* [Im Brennpunkt](/efv/de/home/aktuell/brennpunkt.html "Im Brennpunkt")
* [Archiv](/efv/de/home/aktuell/a.html "Archiv")






### Themen


* [Finanzpolitik, Grundlagen](/efv/de/home/themen/finanzpolitik_grundlagen.html "Finanzpolitik, Grundlagen")
* [Finanzstatistik](/efv/de/home/themen/finanzstatistik.html "Finanzstatistik")
* [Finanzausgleich](/efv/de/home/themen/finanzausgleich.html "Finanzausgleich")
* [Mittelbeschaffung, Vermögens\- und Schuldenverwaltung](/efv/de/home/themen/mittelbeschaff_verm_schuldenverw.html "Mittelbeschaffung, Vermögens- und Schuldenverwaltung")
* [Geld\- und Währungsordnung](/efv/de/home/themen/waehrung_gewinnaussch_int.html "Geld- und Währungsordnung")
* [Projekte](/efv/de/home/themen/projekte.html "Projekte")
* [Publikationen](/efv/de/home/themen/publikationen.html "Publikationen")






### Finanzberichte


* [Bundeshaushalt im Überblick](/efv/de/home/finanzberichterstattung/bundeshaushalt_ueb.html "Bundeshaushalt im Überblick")
* [Finanzberichte](/efv/de/home/finanzberichterstattung/finanzberichte.html "Finanzberichte")
* [Daten](/efv/de/home/finanzberichterstattung/daten.html "Daten")






### Die EFV


* [Auftrag](/efv/de/home/efv/auftrag.html "Auftrag")
* [Organisation](/efv/de/home/efv/organisation.html "Organisation")
* [Rechtliche Grundlagen](/efv/de/home/efv/rechtliche_grdl.html "Rechtliche Grundlagen")
* [E\-Rechnung](/efv/de/home/efv/erechnung.html "E-Rechnung")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellenangebote](/efv/de/home/efv/stellenangebote.html "Stellenangebote")























### Informiert bleiben



Social media links
* [LinkedIn](https://www.linkedin.com/company/72285581/admin/)









---


![Logo der Schweiz](/efv/de/_jcr_content/copyright/image.imagespooler.png/1694447418949/logo.png)




Eidgenössische Finanzverwaltung EFV

* [Rechtliches](https://www.admin.ch/gov/de/start/rechtliches.html)



















