<!--
                                Source URL: https://www.efv.admin.ch/efv/de/home/aktuell/nsb-news_list.html?dyn_organization=603
                                Page ID: 4
                                -->

                                





 

Medienmitteilungen






































* [Homepage](/efv/de/home.html)
* [Main navigation](#main-navigation)
* [Content area](#content)
* [Sitemap](#site-map)
* [Search](#search-field)








Eidgenössische Finanzverwaltung
-------------------------------


* [Der Bundesrat](#)
	+ [Der Bundesrat admin.ch](https://www.admin.ch/gov/de/start.html)
		- [BK: Schweizerische Bundeskanzlei](https://www.bk.admin.ch/bk/de/home.html)
		- [EDA: Eidgenössisches Departement für auswärtige Angelegenheiten](https://www.eda.admin.ch/eda/de/home.html)
		- [EDI: Eidgenössisches Departement des Innern](http://www.edi.admin.ch/)
		- [EJPD: Eidgenössisches Justiz\- und Polizeidepartement](http://www.ejpd.admin.ch/ejpd/de/home.html)
		- [VBS: Eidgenössisches Departement für Verteidigung, Bevölkerungsschutz und Sport](https://www.vbs.admin.ch/de)
		- [EFD: Eidgenössisches Finanzdepartement](https://www.efd.admin.ch/de)
		- [WBF: Eidgenössisches Departement für Wirtschaft, Bildung und Forschung](https://www.wbf.admin.ch/wbf/de/home.html)
		- [UVEK: Eidgenössiches Departement für Umwelt, Verkehr, Energie und Kommunikation](https://www.uvek.admin.ch/uvek/de/home.html)
* [EFD](#)
	+ [EFD: Eidgenössisches Finanzdepartement](https://www.efd.admin.ch/de)
		- [GS\-EFD: Generalsekretariat](https://www.efd.admin.ch/de/generalsekretariat)
		- [SIF: Staatssekretariat für internationale Finanzfragen](https://www.sif.admin.ch/sif/de/home.html)
		- [EFV: Eidgenössische Finanzverwaltung](https://www.efv.admin.ch/efv/de/home.html)
		- [EPA: Eidgenössisches Personalamt](https://www.epa.admin.ch/epa/de/home.html)
		- [ESTV: Eidgenössische Steuerverwaltung](https://www.estv.admin.ch/estv/de/home.html)
		- [BAZG: Bundesamt für Zoll und Grenzsicherheit](https://www.bazg.admin.ch/bazg/de/home.html)
		- [BIT: Bundesamt für Informatik und Telekommunikation](https://www.bit.admin.ch/bit/de/home.html)
		- [BBL: Bundesamt für Bauten und Logistik](https://www.bbl.admin.ch/bbl/de/home.html)
		- [Delegierte des Bundes für Mehrsprachigkeit](https://www.plurilingua.admin.ch/plurilingua/de/home.html)
		- [FINMA: Eidgenössische Finanzmarktaufsicht](https://www.finma.ch/de/)
		- [EFK: Eidgenössischen Finanzkontrolle](http://www.efk.admin.ch/index.php?lang=de)
		- [PUBLICA: Pensionskasse des Bundes](https://publica.ch/)
* [EFV](#)
	+ [Zentrale Ausgleichsstelle ZAS](https://www.zas.admin.ch/zas/de/home.html)
		- [Swissmint](http://www.swissmint.ch/)





Medienmitteilungen
------------------



* DE
* [FR](/efv/fr/home/aktuell/nsb-news_list.html "Französisch")
* [IT](/efv/it/home/aktuell/nsb-news_list.html "Italienisch")
* [EN](/efv/en/home/aktuell/nsb-news_list.html "Englisch")



Service navigation
------------------



* [Startseite](/efv/de/home.html "Startseite")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellen](https://www.efv.admin.ch/efv/de/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/de/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)







[![Eidgenössische Finanzverwaltung EFV](/efv/de/_jcr_content/logo/image.imagespooler.png/1675236523651/logo.png)
Eidgenössische Finanzverwaltung EFV
-----------------------------------](/efv/de/home.html "Startseite")





Suche
-----



















Hauptnavigation
---------------








![Eidgenössische Finanzverwaltung EFV](/etc/designs/core/frontend/guidelines/img/swiss.svg)

[EFV](/efv/de/home.html "Startseite")
-------------------------------------









* [Aktuell](/efv/de/home/aktuell.html)


* [Themen](/efv/de/home/themen.html)


* [Finanzberichte](/efv/de/home/finanzberichterstattung.html)


* [Die EFV](/efv/de/home/efv.html)















Suche
-----



















* [Aktuellcurrent page](/efv/de/home/aktuell.html)
	+ Schliessen
* [Themen](/efv/de/home/themen.html)
	+ Schliessen
* [Finanzberichte](/efv/de/home/finanzberichterstattung.html)
	+ Schliessen
* [Die EFV](/efv/de/home/efv.html)
	+ Schliessen









Breadcrumb
----------


1. [Startseite](/efv/de/home.html "Startseite")
2. [Aktuell](/efv/de/home/aktuell.html "Aktuell")
3. Medienmitteilungen










[Unternavigationen](#collapseSubNav)


[Zurück](/efv/de/home.html)
[Zurück Startseite](/efv/de/home.html)
* [Aktuell](/efv/de/home/aktuell.html)
* Medienmitteilungen selected
* [Im Brennpunkt](/efv/de/home/aktuell/brennpunkt.html)
* [Archiv](/efv/de/home/aktuell/a.html)










[Zum Seitenende](#context-sidebar)







Medienmitteilungen
==================









Dienststellen


 Alle Dienststellen
 

Der Bundesrat (BR)


Bundesanwaltschaft (BA)


Aufsichtsbehörde über die Bundesanwaltschaft (AB\-BA)


Bundesverwaltungsgericht (BVGer)


Bundeskanzlei (BK)
\- Digitale Transformation und IKT\-Lenkung (DTI)
\- Eidgenössischer Datenschutz\- und Öffentlichkeitsbeauftragter (EDÖB)
\- Programm GEVER Bund (GEVER)
\- Verwaltungspraxis der Bundesbehörden (VPB)


Eidgenössisches Departement für auswärtige Angelegenheiten (EDA)


Eidgenössisches Departement des Innern (EDI)
\- Bundesamt für Lebensmittelsicherheit und Veterinärwesen (BLV)
\- Institut für Virologie und Immunologie (IVI)
\- Bundesamt für Gesundheit (BAG)
\- Eidgenössische Qualitätskommission (EQK)
\- Tabakpräventionsfonds (TPF)
\- Eidg. Büro für die Gleichstellung von Frau und Mann (EBG)
\- Generalsekretariat EDI (GS\-EDI)
\- Bundesamt für Kultur (BAK)
\- Schweizerische Nationalbibliothek (NB)
\- Schweizerisches Nationalmuseum (SNM)
\- Schweizerisches Bundesarchiv (BAR)
\- Bundesamt für Meteorologie und Klimatologie (MeteoSchweiz)
\- Bundesamt für Statistik (BFS)
\- Bundesamt für Sozialversicherungen (BSV)
\- Oberaufsichtskommission Berufliche Vorsorge (OAK BV)
\- Staatssekretariat für Bildung und Forschung (SBF) \- ab 1\.1\.2013 SBFI
\- Swissmedic, Schweizerisches Heilmittelinstitut (Swissmedic)
\- Kommissionen des EDI
\- Eidgenössische Kommission gegen Rassismus (EKR)


Eidgenössisches Justiz\- und Polizeidepartement (EJPD)
\- Dienst Überwachung Post\- und Fernmeldeverkehr (Dienst ÜPF)
\- Eidgenössische Spielbankenkommission (ESBK)
\- Generalsekretariat EJPD (GS\-EJPD)
\- Eidgenössische Schiedskommision für die Verwertung von Urheberrechten und verwandten Schutzrechten (ESCHK)
\- Eidgenössische Migrationskommission (EKM)
\- Eidgenössisches Institut für Geistiges Eigentum (IGE)
\- Staatssekretariat für Migration (SEM)
\- Bundesamt für Justiz (BJ)
\- Bundesamt für Polizei (FEDPOL)
\- Eidgenössisches Institut für Metrologie (METAS)
\- Schweiz. Institut für Rechtsvergleichung (SIR)
\- Eidg. Revisionsaufsichtsbehörde (RAB)
\- Nationale Kommission zur Verhütung von Folter (NKVF)
\- Unabhängige Expertenkommission Administrative Versorgungen (UEK)


Eidgenössisches Departement für Verteidigung, Bevölkerungsschutz und Sport (VBS)
\- Generalsekretariat VBS (GS\-VBS)
\- Nachrichtendienst des Bundes (NDB)
\- Bundesamt für Cybersicherheit (BACS)
\- Staatssekretariat für Sicherheitspolitik (SEPOS)
\- Unabhängige Aufsichtsbehörde über die nachrichtendienstlichen Tätigkeiten (AB – ND)
\- Oberauditorat \- Militärjustiz (OA)
\- Gruppe Verteidigung (Verteidigung)
\- Bundesamt für Bevölkerungsschutz (BABS)
\- Nationale Alarmzentrale (NAZ)
\- Bundesamt für Sport (BASPO)
\- Eidgenössische Hochschule für Sport Magglingen EHSM (EHSM)
\- armasuisse (armasuisse)
\- swisstopo \- Bundesamt für Landestopografie (swisstopo)
\- Koordinationsorgan für Geoinformation des Bundes (GKG)
\- Eidgenössische Geologische Fachkommission (EGK)
\- Sicherheitsverbund Schweiz (SVS)
\- Koordinierter Sanitätsdienst \- ab 2023 BABS (KSD)
\- Kommando Operationen \- ab 2019 Gruppe Verteidigung (Kdo Op)
\- Kommando Ausbildung \- ab 2019 Gruppe Verteidigung (Kdo Ausb)
\- Logistikbasis der Armee \- ab 2019 Gruppe Verteidigung (LBA)
\- Führungsunterstützungsbasis \- ab 2019 Gruppe Verteidigung (FUB)


Eidgenössisches Finanzdepartement (EFD)
\- Generalsekretariat EFD (GS\-EFD)
\- Staatssekretariat für internationale Finanzfragen (SIF)
\- Eidg. Finanzverwaltung (EFV)
\- Zentrale Ausgleichsstelle (ZAS)
\- Eidgenössische Steuerverwaltung (ESTV)
\- Bundesamt für Zoll und Grenzsicherheit (BAZG)
\- Eidg. Personalamt (EPA)
\- Bundesamt für Bauten und Logistik (BBL)
\- Bundesamt für Informatik und Telekommunikation (BIT)
\- Pensionskasse des Bundes (PUBLICA)
\- Eidgenössische Münzstätte Swissmint
\- Eidg. Alkoholverwaltung (bis 12\.2017\) (EAV)
\- Alcosuisse (AS)


Eidgenössisches Departement für Wirtschaft, Bildung und Forschung (WBF)
\- Eidgenössische Hochschule für Berufsbildung EHB (EHB)
\- Bundesamt für Zivildienst (ZIVI)
\- Rat der Eidgenössischen Technischen Hochschulen (ETH\-Rat)
\- Kommission für Technologie und Innovation KTI – ab 1\.1\.2018 Innosuisse \- Schweizerische Agentur für Innovationsförderung (KTI)
\- Innosuisse – Schweizerische Agentur für Innovationsförderung (Innosuisse)
\- Generalsekretariat WBF (GS\-WBF)
\- Staatssekretariat für Wirtschaft (SECO)
\- Staatssekretariat für Bildung, Forschung und Innovation (SBFI)
\- Bundesamt für Landwirtschaft (BLW)
\- Bundesamt für wirtschaftliche Landesversorgung (BWL)
\- Bundesamt für Wohnungswesen (BWO)
\- Preisüberwachung (PUE)
\- Wettbewerbskommission (WEKO)
\- Eidgenössisches Büro für Konsumentenfragen
\- Ecole Polytechnique Fédérale de Lausanne (EPFL)
\- Paul Scherrer Institut (PSI)
\- Eidgenössische Forschungsanstalt für Wald, Schnee und Landschaft (WSL)
\- Eidg. Materialprüfungs\- und Forschungsanstalt (Empa)
\- Eawag: Wasserforschungsinstitut des ETH\-Bereichs (Eawag)
\- Schweizerischer Wissenschaftsrat (SWR)
\- AGROSCOPE
\- Schweizerische Hochschulkonferenz (SHK)
\- Bundesamt für Veterinärwesen (BVET) \- ab 2013 im EDI
\- Bundesamt für Berufsbildung und Technologie (BBT) \- ab 1\.1\.2013 SBFI
\- Integrationsbüro EDA/EVD (IB) \- ab 1\.1\.2013 im EDA


Eidgenössisches Departement für Umwelt, Verkehr, Energie und Kommunikation (UVEK)
\- Kommission für den Eisenbahnverkehr RailCom (RailCom)
\- Generalsekretariat UVEK (GS\-UVEK)
\- Schweizerische Sicherheitsuntersuchungsstelle SUST, Bereich Bahnen und Schiffe (SUST Bahnen Schiffe)
\- Bundesamt für Strassen (ASTRA)
\- Bundesamt für Verkehr (BAV)
\- Bundesamt für Zivilluftfahrt (BAZL)
\- Bundesamt für Energie (BFE)
\- Bundesamt für Raumentwicklung (ARE)
\- Bundesamt für Kommunikation (BAKOM)
\- Bundesamt für Umwelt BAFU (BAFU)
\- Fachstab Naturgefahren des Bundes
\- Nationale Plattform Naturgefahren (PLANAT)
\- Schweizerische Sicherheitsuntersuchungsstelle SUST, Bereich Aviatik (SUST Aviatik)
\- Eidgenössische Kommunikationskommission ComCom (ComCom)
\- Unabhängige Beschwerdeinstanz für Radio und Fernsehen (UBI)
\- Eidgenössische Postkommission PostCom (PostCom)
\- Eidgenössisches Nuklearsicherheitsinspektorat (ENSI)
\- Eidgenössische Elektrizitätskommission (ElCom)
\- Eidgenössische Kommission für Lufthygiene (EKL)
\- Eidgenössische Kommission für Lärmbekämpfung (EKLB)
\- Eidgenössische Natur\- und Heimatschutzkommission (ENHK)
\- Eidgenössische Ethikkommission für die Biotechnologie im Ausserhumanbereich (EKAH)
\- Eidgenössische Fachkommission für biologische Sicherheit (EFBS)
\- Eidgenössische Kommission für nukleare Sicherheit (KNS)
\- Eidgenössisches Starkstrominspektorat ESTI (ESTI)




Thema


 Alle Themen
 
Amtliche Veröffentlichungen (wird nicht mehr angeboten)
Arbeit
Armee
Ausserordentliche Lagen
Behörden
Bibliotheken und Archive
Bildung und Forschung
Bundespersonal
Bundespräsident/\-in
Bundesrat
Bund und Kantone
Energie
Europa
Finanzplatz
Frankenstärke
Gerichte
Gesundheit
Informatik und E\-Government
Konsum
Kriminalität
Kultur
Landwirtschaft
Medien
Migration
Öffentliche Beschaffungen
Öffentliche Finanzen
Parlament
Politische Rechte
Raumplanung
Recht
Reisen und Tourismus
Schweiz und Ausland
Sicherheit
Soziales
Sport
Statistik
Steuern
Technologie
Telekommunikation
Umwelt und Natur
Verkehr
Wirtschaft
Zoll
Zuwanderung – Umsetzung der neuen Verfassungsbestimmungen



Von



Bis



Suchen







Zur Darstellung der Medienmitteilungen wird Java Script benötigt. Sollten Sie Java Script nicht aktivieren können oder wollen haben sie mit unten stehendem Link die Möglichkeit auf die New Service Bund Seite zu gelangen und dort die Mitteilungn zu lesen.






[Zur externen NSB Seite](https://www.newsd.admin.ch/newsd/feeds/rss?lang=de&org-nr=603&topic=&keyword=&offer-nr=&catalogueElement=&kind=M,R,S&start_date=2023-01-01)









* [Links zum Thema](#links_zum_thema__content_efv_de_home_aktuell_nsb-news_list_jcr_content_par_tabs)
* [Externe Links](#externe_links__content_efv_de_home_aktuell_nsb-news_list_jcr_content_par_tabs)





Links zum Thema
---------------




[News abonnieren](https://www.admin.ch/gov/de/start/dokumentation/medienmitteilungen/medienmitteilungen-abonnieren.html?lang=de)






Externe Links
-------------




[Medienmitteilungen EFD](https://www.efd.admin.ch/efd/de/home/dokumentation/nsb-news_list.html)






[Medienmitteilungen der Bundesverwaltung](https://www.admin.ch/gov/de/start/dokumentation/medienmitteilungen.html)












Letzte Änderung 30\.01\.2024






[Zum Seitenanfang](#) 







Social share






* [Kontakt](#contact)




Kontakt
-------


**Medienanfragen**Kommunikation EFV


Philipp Rohr, Leitung  

Michael Girod, Mediensprecher  

 Sarah Pfäffli, Mediensprecherin





 Tel.
 


[\+41 58 465 16 06](tel:+41 58 465 16 06) 



[kommunikation@efv.admin.ch](mailto:kommunikation@efv.admin.ch) 



 


**Medienmitteilungen abonnieren** [News\-Abo](https://www.admin.ch/gov/de/start/dokumentation/medienmitteilungen/medienmitteilungen-abonnieren.html?lang=de)  






[Kontaktinformationen drucken](# "Druckversion") 







#### Einkaufskorb














https://www.efv.admin.ch/content/efv/de/home/aktuell/nsb\-news\_list.html

Footer
------



### Eidgenössische Finanzverwaltung EFV



* [Startseite](/efv/de/home.html "Startseite")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellen](https://www.efv.admin.ch/efv/de/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/de/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)





Footer
------


[Sitemap](#site-map)



### Aktuell


* [Medienmitteilungen](/efv/de/home/aktuell/nsb-news_list.html "Medienmitteilungen")
* [Im Brennpunkt](/efv/de/home/aktuell/brennpunkt.html "Im Brennpunkt")
* [Archiv](/efv/de/home/aktuell/a.html "Archiv")






### Themen


* [Finanzpolitik, Grundlagen](/efv/de/home/themen/finanzpolitik_grundlagen.html "Finanzpolitik, Grundlagen")
* [Finanzstatistik](/efv/de/home/themen/finanzstatistik.html "Finanzstatistik")
* [Finanzausgleich](/efv/de/home/themen/finanzausgleich.html "Finanzausgleich")
* [Mittelbeschaffung, Vermögens\- und Schuldenverwaltung](/efv/de/home/themen/mittelbeschaff_verm_schuldenverw.html "Mittelbeschaffung, Vermögens- und Schuldenverwaltung")
* [Geld\- und Währungsordnung](/efv/de/home/themen/waehrung_gewinnaussch_int.html "Geld- und Währungsordnung")
* [Projekte](/efv/de/home/themen/projekte.html "Projekte")
* [Publikationen](/efv/de/home/themen/publikationen.html "Publikationen")






### Finanzberichte


* [Bundeshaushalt im Überblick](/efv/de/home/finanzberichterstattung/bundeshaushalt_ueb.html "Bundeshaushalt im Überblick")
* [Finanzberichte](/efv/de/home/finanzberichterstattung/finanzberichte.html "Finanzberichte")
* [Daten](/efv/de/home/finanzberichterstattung/daten.html "Daten")






### Die EFV


* [Auftrag](/efv/de/home/efv/auftrag.html "Auftrag")
* [Organisation](/efv/de/home/efv/organisation.html "Organisation")
* [Rechtliche Grundlagen](/efv/de/home/efv/rechtliche_grdl.html "Rechtliche Grundlagen")
* [E\-Rechnung](/efv/de/home/efv/erechnung.html "E-Rechnung")
* [Kontakt](/efv/de/home/efv/kontakt.html "Kontakt")
* [Stellenangebote](/efv/de/home/efv/stellenangebote.html "Stellenangebote")























### Informiert bleiben



Social media links
* [LinkedIn](https://www.linkedin.com/company/72285581/admin/)









---


![Logo der Schweiz](/efv/de/_jcr_content/copyright/image.imagespooler.png/1694447418949/logo.png)




Eidgenössische Finanzverwaltung EFV

* [Rechtliches](https://www.admin.ch/gov/de/start/rechtliches.html)



















