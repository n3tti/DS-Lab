<!--
                                Source URL: https://www.efv.admin.ch/efv/fr/home/efv/erechnung/aktuell.html
                                Page ID: 2
                                -->

                                





 

Actualités








































* [Homepage](/efv/fr/home.html)
* [Main navigation](#main-navigation)
* [Content area](#content)
* [Sitemap](#site-map)
* [Search](#search-field)








Administration fédérale des finances
------------------------------------


* [Le Conseil fédéral](#)
	+ [Le Conseil fédéral admin.ch](https://www.admin.ch/gov/fr/accueil.html)
		- [ChF: Chancellerie fédérale](https://www.bk.admin.ch/bk/fr/home.html)
		- [DFAE: Département fédéral des affaires étrangères](https://www.eda.admin.ch/eda/fr/home.html)
		- [DFI: Département fédéral de l'intérieur](https://www.edi.admin.ch/edi/fr/home.html)
		- [DFJP: Département fédéral de justice et police](https://www.ejpd.admin.ch/content/ejpd/fr/home.html)
		- [DDPS: Département fédéral de la défense, de la protection de la population et des sports](https://www.vbs.admin.ch/fr)
		- [DFF: Département fédéral des finances](https://www.efd.admin.ch/fr)
		- [DEFR: Département fédéral de l'économie, de la formation et de la recherche](https://www.wbf.admin.ch/wbf/fr/home.html)
		- [DETEC: Département fédéral de l'environnement, des transports, de l'énergie et de la communication](https://www.uvek.admin.ch/uvek/fr/home.html)
* [DFF](#)
	+ [DFF: Département fédéral des finances](https://www.efd.admin.ch/fr)
		- [SG\-DFF: Le Secrétariat général](https://www.efd.admin.ch/fr/secretariat-general-dff)
		- [SIF: Secrétariat d’État aux questions financières internationales](https://www.sif.admin.ch/sif/fr/home.html)
		- [AFF: Administration fédérale des finances](https://www.efv.admin.ch/efv/fr/home.html)
		- [OFPER: Office fédéral du personnel](https://www.epa.admin.ch/epa/fr/home.html)
		- [AFC: Administration fédérale des contributions](https://www.estv.admin.ch/estv/fr/home.html)
		- [OFDF: Office fédéral de la douane et de la sécurité des frontières](https://www.bazg.admin.ch/bazg/fr/home.html)
		- [OFIT: Office fédéral de l'informatique et de la télécommunication](https://www.bit.admin.ch/bit/fr/home.html)
		- [OFCL: Office fédéral des constructions et de la logistique](https://www.bbl.admin.ch/bbl/fr/home.html)
		- [Déléguée fédérale au plurilinguisme](https://www.plurilingua.admin.ch/plurilingua/fr/home.html)
		- [FINMA: Autorité fédérale de surveillance des marchés financiers](https://www.finma.ch/fr/)
		- [CDF: Contrôle fédéral des finances](https://www.efk.admin.ch/fr/)
		- [PUBLICA: Caisse fédérale de pensions](https://publica.ch/fr/page-d-accueil)
* [AFF](#)
	+ [Centrale de compensation CdC](https://www.zas.admin.ch/zas/fr/home.html)
		- [Swissmint](https://www.swissmint.ch/fr)





Actualités
----------



* [DE](/efv/de/home/efv/erechnung/aktuell.html "allemand")
* FR
* [IT](/efv/it/home/efv/erechnung/aktuell.html "italien")
* [EN](/efv/en/home/efv/erechnung/aktuell.html "anglais")



Service navigation
------------------



* [Page d'accueil](/efv/fr/home.html "Page d'accueil")
* [Contact](/efv/fr/home/efv/kontakt.html "Contact")
* [Postes vacants](https://www.efv.admin.ch/efv/fr/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/fr/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)







[![Administration fédérale des finances AFF](/efv/fr/_jcr_content/logo/image.imagespooler.png/1675236504630/logo.png)
Administration fédérale des finances AFF
----------------------------------------](/efv/fr/home.html "Page d'accueil")





Recherche
---------



















Navigation
----------








![](/efv/fr/_jcr_content/navigation/icon.imagespooler.png/1463575638314/swiss.png)

[AFF](/efv/fr/home.html "Page d'accueil")
-----------------------------------------









* [Actualité](/efv/fr/home/aktuell.html)


* [Thèmes](/efv/fr/home/themen.html)


* [Rapports financiers](/efv/fr/home/finanzberichterstattung.html)


* [L'AFF](/efv/fr/home/efv.html)















Recherche
---------



















* [Actualité](/efv/fr/home/aktuell.html)
	+ Fermer
* [Thèmes](/efv/fr/home/themen.html)
	+ Fermer
* [Rapports financiers](/efv/fr/home/finanzberichterstattung.html)
	+ Fermer
* [L'AFFcurrent page](/efv/fr/home/efv.html)
	+ Fermer









Breadcrumb
----------


1. [Page d'accueil](/efv/fr/home.html "Page d'accueil")
2. [L'AFF](/efv/fr/home/efv.html "L'AFF")
3. [E\-Facture](/efv/fr/home/efv/erechnung.html "E-Facture")
4. Actualités










[Unternavigation](#collapseSubNav)


[Zurück](/efv/fr/home/efv.html)
[Zurück zu L'AFF](/efv/fr/home/efv.html)
* [E\-Facture](/efv/fr/home/efv/erechnung.html)
* Actualités selected
* [Brève introduction](/efv/fr/home/efv/erechnung/kurze-einfuehrung.html)
* [Établir des factures électroniques](/efv/fr/home/efv/erechnung/e-rechnung-zustellen.html)
* [Recevoir des factures électroniques](/efv/fr/home/efv/erechnung/e-rechnung-empfangen.html)
* [Liste des unités administratives](/efv/fr/home/efv/erechnung/liste-verwaltungseinheiten.html)










[Context sidebar](#context-sidebar)








Actualités
==========






![e-facture](/efv/fr/home/efv/erechnung/aktuell/_jcr_content/par/textimage_1538754464/image.imagespooler.jpg/1649751358562/180.1000/e-rechnung_fr.png)
Réglez vos comptes avec nous – mais sous forme électronique, s’il vous plaît!
-----------------------------------------------------------------------------





Envoyez vos factures par voie électronique
------------------------------------------





Au lieu d'imprimer votre facture et de l'envoyer par la poste à l'administration fédérale, vous pouvez transmettre vos données de facturation à un fournisseur de services de facturation par voie électronique. Vous économisez ainsi du temps et de l'argent, et votre facture est traitée rapidement et de manière entièrement électronique. Les factures peuvent être transmises par différents canaux, sous la forme de fichiers structurés ou en tant que PDF.


Informations complémentaires:


[Établir des factures électronique](/efv/fr/home/efv/erechnung/e-rechnung-zustellen.html)


[Recevoir des factures électroniques](/efv/fr/home/efv/erechnung/e-rechnung-empfangen.html)


Vous avez une question concernant une facture en particulier? Veuillez vous adresser au centre de services en matière de finances: [e\-rechnung@efv.admin.ch](mailto:e-rechnung@efv.admin.ch).





La proportion de factures électroniques s'élève déjà à plus de 75 %
-------------------------------------------------------------------





La Confédération reçoit aujourd'hui plus de 75 % des factures par voie électronique. Depuis que l'administration fédérale a imposé la facturation électronique à ses fournisseurs, la proportion de factures électroniques n'a cessé d'augmenter, passant de 18 % en décembre 2014 à plus de 75 % en décembre 2021\. Cela équivaut à environ 488 000 factures sur les 650 000 factures émises par an. L'obligation ne s'applique pas à toutes les factures: celles portant sur des menues acquisitions ne sont pas concernées.


S'agissant des factures destinées à des clients externes, l'administration fédérale transmet environ 25 % des factures par voie électronique (factures électroniques structurées ou envoi par courriel de factures en PDF). La facturation électronique répondant à un besoin important de la clientèle, cette proportion est appelée à augmenter.









Dernière modification 08\.06\.2022






[Début de la page](#) 







Social share










#### Panier d'achat














https://www.efv.admin.ch/content/efv/fr/home/efv/erechnung/aktuell.html

Footer
------




### Administration fédérale des finances AFF



* [Page d'accueil](/efv/fr/home.html "Page d'accueil")
* [Contact](/efv/fr/home/efv/kontakt.html "Contact")
* [Postes vacants](https://www.efv.admin.ch/efv/fr/home/efv/stellenangebote.html)
* [News](https://www.efv.admin.ch/efv/fr/home/aktuell/nsb-news_list.html?dyn_organization=603)
* [e\-Portal: Services](https://eportal.admin.ch)





Footer
------


[Sitemap](#site-map)



### Actualités


* [Informations destinées aux médias](/efv/fr/home/aktuell/nsb-news_list.html "Informations destinées aux médias ")
* [L'actualité de l'AFF](/efv/fr/home/aktuell/brennpunkt.html "L'actualité de l'AFF")
* [Archive](/efv/fr/home/aktuell/a.html "Archive")






### Thèmes


* [Politique budgétaire, Bases](/efv/fr/home/themen/finanzpolitik_grundlagen.html "Politique budgétaire, Bases")
* [Statistique financière](/efv/fr/home/themen/finanzstatistik.html "Statistique financière")
* [Péréquation financière](/efv/fr/home/themen/finanzausgleich.html "Péréquation financière")
* [Acquisition de fonds, gestion de la fortune et de la dette](/efv/fr/home/themen/mittelbeschaff_verm_schuldenverw.html "Acquisition de fonds, gestion de la fortune et de la dette")
* [Régime monétaire](/efv/fr/home/themen/waehrung_gewinnaussch_int.html "Régime monétaire")
* [Projets](/efv/fr/home/themen/projekte.html "Projets")
* [Publications](/efv/fr/home/themen/publikationen.html "Publications")






### Rapports financiers


* [Aperçu des finances fédérales](/efv/fr/home/finanzberichterstattung/bundeshaushalt_ueb.html "Aperçu des finances fédérales")
* [Rapports financiers](/efv/fr/home/finanzberichterstattung/finanzberichte.html "Rapports financiers")
* [Données](/efv/fr/home/finanzberichterstattung/daten.html "Données")






### L'AFF


* [Mandat](/efv/fr/home/efv/auftrag.html "Mandat")
* [Organisation](/efv/fr/home/efv/organisation.html "Organisation")
* [Bases légales](/efv/fr/home/efv/rechtliche_grdl.html "Bases légales")
* [E\-Facture](/efv/fr/home/efv/erechnung.html "E-Facture")
* [Contact](/efv/fr/home/efv/kontakt.html "Contact")
* [Offres d'emploi](/efv/fr/home/efv/stellenangebote.html "Offres d'emploi")























### Restez informé



Social media links
* [LinkedIn](https://www.linkedin.com/company/72285581/admin/)









---


![Administration fédérale des finances AFF](/efv/fr/_jcr_content/logo/image.imagespooler.png/1675236504630/logo.png)




Administration fédérale des finances AFF

* [Informations juridiques](https://www.admin.ch/gov/fr/accueil/conditions-utilisation.html)



















